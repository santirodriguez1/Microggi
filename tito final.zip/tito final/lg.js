document.getElementById("iniciosesion").addEventListener("submit", function(event) {
    event.preventDefault(); // Evita que el formulario se envíe automáticamente

    // Obtén los valores de los campos de entrada
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    // Verifica si el usuario y la contraseña son correctos
    if (username === "admin" && password === "1234") {
        // Redirige a agregarproducto.html si los datos son correctos
        window.location.href = "agregarproducto.html";
    } else {
        // Muestra un mensaje de error si los datos son incorrectos
        alert("Usuario y/o contraseña incorrectos");
    }
});
