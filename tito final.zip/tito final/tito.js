// Lista de productos para el autocompletado
const productos = [
    "Micrófono Estable",
    "Micrófono Portátil",
    "Micrófono Inalámbrico",
    "Micrófono Cardioide"
];

function autocomplete(input, array) {
    let currentFocus;

    input.addEventListener("input", function() {
        let list, item, val = this.value;
        closeAllLists();
        if (!val) return false;
        currentFocus = -1;

        list = document.createElement("div");
        list.setAttribute("class", "autocomplete-items");
        this.parentNode.appendChild(list);

        array.forEach(product => {
            if (product.substr(0, val.length).toUpperCase() === val.toUpperCase()) {
                item = document.createElement("div");
                item.innerHTML = "<strong>" + product.substr(0, val.length) + "</strong>" + product.substr(val.length);
                item.addEventListener("click", function() {
                    input.value = product;
                    closeAllLists();
                });
                list.appendChild(item);
            }
        });
    });

    input.addEventListener("keydown", function(e) {
        let items = document.querySelectorAll(".autocomplete-items div");
        if (e.key === "ArrowDown") {
            currentFocus++;
            addActive(items);
        } else if (e.key === "ArrowUp") {
            currentFocus--;
            addActive(items);
        } else if (e.key === "Enter") {
            e.preventDefault();
            if (currentFocus > -1) items[currentFocus].click();
        }
    });

    function addActive(items) {
        if (!items) return false;
        removeActive(items);
        if (currentFocus >= items.length) currentFocus = 0;
        if (currentFocus < 0) currentFocus = items.length - 1;
        items[currentFocus].classList.add("autocomplete-active");
    }

    function removeActive(items) {
        items.forEach(item => item.classList.remove("autocomplete-active"));
    }

    function closeAllLists() {
        document.querySelectorAll(".autocomplete-items").forEach(list => list.remove());
    }

    document.addEventListener("click", e => closeAllLists(e.target));
}

autocomplete(document.getElementById("search-input"), productos);
